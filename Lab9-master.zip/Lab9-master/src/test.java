public class test {
    public static void main (String[] args) {
        Auto myAuto1  = new Auto("Ford", 180);
        System.out.println(myAuto1.getFirm() + " " + myAuto1.getMaxSpeed());
    }
}